program <-
function(data_train, data_test) {
    gs = colnames(data_test)[-(1:3)]
    data_pred = data_test[,"histology"]
    names(data_pred) = rownames(data_test)
    data_train$histology = as.factor(data_train$histology)
    data_test$histology  = as.factor(data_test$histology )

    ##
    ## YOUR CODE BEGINS HERE
    ## 
    
    # use the first gene as predictor for histology
    g = gs[1] 
    plot(data_train$histology, data_train[,g])
    formula = as.formula(paste0("histology~", g))
    print(formula)
    m = glm(formula, data_train, family =binomial(link = 'logit'))
    pred = predict.glm(m, data_test, type="response")    
    data_pred = ifelse(pred<0.5, "AD", "SC")


    # # get gene with best logistic regression model as predictor for histology
    # ms = sapply(gs, function(g){
    #   # print(g)
    #   formula = as.formula(paste0("histology~", g))
    #   m = glm(formula, data_train, family =binomial(link = 'logit'))
    #   pval = summary(m)$coefficients[2,4]
    #   beta = m$coefficients[[2]]
    #   return(c(pval=pval, beta=beta))
    # })
    # plot(ms["beta",], -log10(ms["pval",]))
    # g = colnames(ms[,order(ms["pval",])])[1]
    # formula = as.formula(paste0("histology~", g))
    # print(formula)
    # m = glm(formula, data_train, family =binomial(link = 'logit'))
    # pred = predict.glm(m, data_test, type="response")
    # data_pred = ifelse(pred<0.5, "AD", "SC")

    
    ##
    ## YOUR CODE ENDS HERE
    ##

    return(data_pred)
    
}
